/* ═══════════════════════════════════════
   NEXUS GAMES — Main JavaScript
   (Games, Modals, Wishlist, Search)
   ═══════════════════════════════════════ */

// ── Game Data ─────────────────────────────────────────────────
const games = [
    {
        id: 1,
        title: "Stellar Odyssey",
        price: "999",
        icon: "🚀",
        tags: ["Стратегия", "Космос", "4X"],
        category: "new",
        description: "Исследуйте бесконечные просторы космоса в этой грандиозной космической стратегии."
    },
    {
        id: 2,
        title: "Shadow Legends",
        price: "1499",
        icon: "⚔️",
        tags: ["RPG", "Фэнтези", "Мультиплеер"],
        category: "popular",
        description: "Эпическое фэнтези приключение в мире меча и магии."
    },
    {
        id: 3,
        title: "Velocity Racers",
        price: "799",
        icon: "🏎️",
        tags: ["Гонки", "Аркада", "Мультиплеер"],
        category: "sale",
        description: "Футуристические гонки на максимальной скорости."
    },
    {
        id: 4,
        title: "Zombie Warfare",
        price: "1199",
        icon: "🧟",
        tags: ["Шутер", "Выживание", "Хоррор"],
        category: "popular",
        description: "Выживайте в мире зомби-апокалипсиса."
    },
    {
        id: 5,
        title: "Empire Builder",
        price: "899",
        icon: "🏰",
        tags: ["Стратегия", "Градостроитель", "Экономика"],
        category: "new",
        description: "Постройте величайшую империю в истории."
    },
    {
        id: 6,
        title: "Mystic Quest",
        price: "1299",
        icon: "🔮",
        tags: ["RPG", "Приключения", "Магия"],
        category: "sale",
        description: "Откройте тайны древней магии в этом приключении."
    },
    {
        id: 7,
        title: "Battle Royale X",
        price: "Бесплатно",
        icon: "🎯",
        tags: ["Шутер", "Battle Royale", "PvP"],
        category: "popular",
        description: "100 игроков, один победитель. Последний оставшийся в живых."
    },
    {
        id: 8,
        title: "Pixel Adventures",
        price: "599",
        icon: "👾",
        tags: ["Платформер", "Инди", "Ретро"],
        category: "new",
        description: "Классический платформер в современной обертке."
    },
    {
        id: 9,
        title: "Cyber Hacker",
        price: "1099",
        icon: "💻",
        tags: ["Симулятор", "Киберпанк", "Головоломка"],
        category: "new",
        description: "Станьте хакером в киберпанк мире будущего."
    }
];

// ── Render Games ──────────────────────────────────────────────
function renderGames(filter = 'all') {
    const grid = document.getElementById('gamesGrid');
    let filteredGames;
    if (filter === 'all')   filteredGames = games;
    else if (filter === 'free') filteredGames = games.filter(g => g.price === 'Бесплатно');
    else filteredGames = games.filter(g => g.category === filter);

    grid.innerHTML = filteredGames.map((game, index) => {
        const inWishlist = wishlist.some(g => g.id === game.id);
        return `
        <div class="game-card" data-game-id="${game.id}"
             onclick="showGameModal('${game.title}', '${game.price}', '${game.tags.join(', ')}')">
            <div class="game-thumbnail"
                 style="background: linear-gradient(${135 + index * 30}deg,
                        hsl(${200 + index * 30}, 70%, 60%) 0%,
                        hsl(${250 + index * 30}, 70%, 60%) 100%)">
                ${game.icon}
            </div>
            <div class="game-info">
                <h3 class="game-title">${game.title}</h3>
                <div class="game-tags">
                    ${game.tags.map(tag => `<span class="game-tag">${tag}</span>`).join('')}
                </div>
                <div class="game-footer">
                    <span class="game-price">
                        ${game.price}${game.price !== 'Бесплатно' ? ' ₽' : ''}
                    </span>
                    <button class="wishlist-btn"
                            style="color:${inWishlist ? 'var(--accent-pink)' : ''}"
                            onclick="event.stopPropagation(); toggleWishlist(this, ${game.id})">
                        ${inWishlist ? '♥' : '♡'}
                    </button>
                </div>
            </div>
        </div>`;
    }).join('');
}

// ── Game Detail Modal ─────────────────────────────────────────
function showGameModal(title, price, tags) {
    const modal = document.getElementById('gameModal');
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalPrice').textContent = price + (price !== 'Бесплатно' ? ' ₽' : '');
    document.getElementById('modalTags').textContent  = tags;

    const game = games.find(g => g.title === title);
    if (game) {
        document.getElementById('modalImage').textContent       = game.icon;
        document.getElementById('modalDescription').textContent = game.description;

        const wlBtn      = document.getElementById('modalWishlistBtn');
        const inWishlist = wishlist.some(g => g.id === game.id);
        wlBtn.innerHTML       = inWishlist ? '♥ В желаемом' : '♡ В желаемое';
        wlBtn.style.background = inWishlist ? 'rgba(255,0,110,0.4)' : 'rgba(255,0,110,0.2)';
    }

    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('gameModal').classList.remove('active');
    document.body.style.overflow = 'auto';
}

// ── Wishlist System ───────────────────────────────────────────
let wishlist = [];

function toggleWishlist(btn, gameId) {
    const game = games.find(g => g.id === gameId);
    if (!game) return;
    const idx = wishlist.findIndex(g => g.id === gameId);
    if (idx === -1) {
        wishlist.push(game);
        btn.textContent  = '♥';
        btn.style.color  = 'var(--accent-pink)';
        showWishlistToast(game.title, true);
    } else {
        wishlist.splice(idx, 1);
        btn.textContent  = '♡';
        btn.style.color  = 'var(--text-secondary)';
        showWishlistToast(game.title, false);
    }
    updateWishlistBadge();
}

function toggleWishlistFromModal() {
    const title = document.getElementById('modalTitle').textContent;
    const game  = games.find(g => g.title === title);
    if (!game) return;
    const btn = document.getElementById('modalWishlistBtn');
    const idx = wishlist.findIndex(g => g.id === game.id);
    if (idx === -1) {
        wishlist.push(game);
        btn.innerHTML       = '♥ В желаемом';
        btn.style.background = 'rgba(255,0,110,0.4)';
        showWishlistToast(game.title, true);
    } else {
        wishlist.splice(idx, 1);
        btn.innerHTML       = '♡ В желаемое';
        btn.style.background = 'rgba(255,0,110,0.2)';
        showWishlistToast(game.title, false);
    }
    updateWishlistBadge();
    syncCardWishlistBtn(game.id, idx === -1);
}

function syncCardWishlistBtn(gameId, added) {
    document.querySelectorAll('.game-card').forEach(card => {
        if (parseInt(card.dataset.gameId) === gameId) {
            const btn = card.querySelector('.wishlist-btn');
            if (btn) {
                btn.textContent  = added ? '♥' : '♡';
                btn.style.color  = added ? 'var(--accent-pink)' : '';
            }
        }
    });
}

function updateWishlistBadge() {
    const count = wishlist.length;
    const badge = document.getElementById('wlBadge');
    badge.textContent = count;
    badge.classList.toggle('visible', count > 0);
}

function openWishlist(e) {
    if (e) e.preventDefault();
    renderWishlistPanel();
    document.getElementById('wishlistOverlay').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeWishlist() {
    document.getElementById('wishlistOverlay').classList.remove('active');
    document.body.style.overflow = 'auto';
}

function closeWishlistOnOverlay(e) {
    if (e.target === e.currentTarget) closeWishlist();
}

function renderWishlistPanel() {
    const container = document.getElementById('wishlistItems');
    const empty     = document.getElementById('wishlistEmpty');
    const footer    = document.getElementById('wishlistFooter');
    document.getElementById('wishlistCountLabel').textContent = wishlist.length;

    if (wishlist.length === 0) {
        empty.style.display     = 'block';
        container.innerHTML     = '';
        footer.style.display    = 'none';
        return;
    }
    empty.style.display  = 'none';
    footer.style.display = 'block';
    container.innerHTML  = wishlist.map((game, index) => `
        <div class="wishlist-item" id="wl-item-${game.id}">
            <div class="wishlist-item-icon"
                 style="background: linear-gradient(${135 + index * 30}deg,
                        hsl(${200 + index * 30}, 70%, 60%) 0%,
                        hsl(${250 + index * 30}, 70%, 60%) 100%)">
                ${game.icon}
            </div>
            <div class="wishlist-item-info">
                <div class="wishlist-item-title">${game.title}</div>
                <div class="wishlist-item-price">
                    ${game.price}${game.price !== 'Бесплатно' ? ' ₽' : ''}
                </div>
            </div>
            <div class="wishlist-item-actions">
                <button class="wl-buy-btn"    onclick="buyFromWishlist(${game.id})">Купить</button>
                <button class="wl-remove-btn" onclick="removeFromWishlist(${game.id})">✕</button>
            </div>
        </div>
    `).join('');
}

function removeFromWishlist(gameId) {
    wishlist = wishlist.filter(g => g.id !== gameId);
    updateWishlistBadge();
    syncCardWishlistBtn(gameId, false);

    const modal = document.getElementById('gameModal');
    if (modal.classList.contains('active')) {
        const title = document.getElementById('modalTitle').textContent;
        const game  = games.find(g => g.id === gameId);
        if (game && game.title === title) {
            const btn = document.getElementById('modalWishlistBtn');
            btn.innerHTML       = '♡ В желаемое';
            btn.style.background = 'rgba(255,0,110,0.2)';
        }
    }
    renderWishlistPanel();
}

function buyFromWishlist(gameId) {
    const game = games.find(g => g.id === gameId);
    if (!game) return;
    closeWishlist();
    openPurchaseModal(null, game.title, game.price + (game.price !== 'Бесплатно' ? ' ₽' : ''));
}

function clearWishlist() {
    wishlist.forEach(g => syncCardWishlistBtn(g.id, false));
    wishlist = [];
    updateWishlistBadge();
    renderWishlistPanel();
}

function showWishlistToast(title, added) {
    let toast = document.getElementById('wlToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'wlToast';
        toast.style.cssText = `
            position: fixed; bottom: 2rem; left: 50%; transform: translateX(-50%);
            background: rgba(21,27,46,0.97); border: 1px solid rgba(255,0,110,0.4);
            border-radius: 12px; padding: 0.8rem 1.5rem; z-index: 99999;
            font-family: 'Exo 2', sans-serif; font-size: 0.9rem; color: var(--text-primary);
            box-shadow: 0 8px 30px rgba(0,0,0,0.5); transition: opacity 0.4s;
            white-space: nowrap;
        `;
        document.body.appendChild(toast);
    }
    toast.innerHTML = added
        ? `♥ <strong style="color:var(--accent-pink)">${title}</strong> добавлена в желаемое`
        : `✕ <strong style="color:var(--text-secondary)">${title}</strong> удалена из желаемого`;
    toast.style.opacity = '1';
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { toast.style.opacity = '0'; }, 2500);
}

// ── Event Wiring ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {

    // Initial render
    renderGames();

    // Filter tabs
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            renderGames(this.dataset.filter);
        });
    });

    // Nav filter links
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const filter = this.dataset.filter;
            if (filter) {
                const filterBtn = document.querySelector(`.filter-btn[data-filter="${filter}"]`);
                if (filterBtn) {
                    filterBtn.click();
                    window.scrollTo({ top: document.querySelector('.games-section').offsetTop - 100, behavior: 'smooth' });
                }
            }
        });
    });

    // Search
    document.getElementById('searchInput').addEventListener('input', function (e) {
        const term = e.target.value.toLowerCase();
        document.querySelectorAll('.game-card').forEach(card => {
            const title = card.querySelector('.game-title').textContent.toLowerCase();
            card.style.display = title.includes(term) ? 'block' : 'none';
        });
    });

    // Close game modal on overlay click
    document.getElementById('gameModal').addEventListener('click', function (e) {
        if (e.target === this) closeModal();
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });
});
