/* ═══════════════════════════════════════
   NEXUS GAMES — Footer JavaScript
   (Info Modals, Social Links, Footer Nav)
   ═══════════════════════════════════════ */

// ── Info Modal Content ────────────────────────────────────────
const infoContent = {
    preorder: {
        title: '🎮 Предзаказы',
        html: `
            <div class="info-modal-section">
                <h4>Как работают предзаказы</h4>
                <p>Оформите предзаказ на ещё не вышедшие игры и получите их в день релиза автоматически. Оплата списывается в день выхода игры.</p>
            </div>
            <div class="info-modal-section">
                <h4>Преимущества предзаказа</h4>
                <ul>
                    <li>Скидка до <strong style="color:var(--accent-cyan)">20%</strong> по сравнению с ценой после выхода</li>
                    <li>Эксклюзивные бонусы: скины, DLC, игровая валюта</li>
                    <li>Гарантированный доступ в день релиза</li>
                    <li>Отмена предзаказа в любой момент без комиссии</li>
                </ul>
            </div>
            <div class="info-modal-section">
                <h4>Скоро в продаже</h4>
                <span class="info-badge">Nexus Prime 2 • Q3 2026</span>
                <span class="info-badge">Shadow Worlds • Q4 2026</span>
                <span class="info-badge">Quantum Break 2 • 2027</span>
            </div>`
    },
    free: {
        title: '🆓 Бесплатные игры',
        html: `
            <div class="info-modal-section">
                <p>На NEXUS представлено более <strong style="color:var(--accent-cyan)">150+</strong> бесплатных игр. Просто нажмите «Получить» и играйте!</p>
            </div>
            <div class="info-modal-section">
                <h4>Категории</h4>
                <span class="info-badge">Battle Royale</span>
                <span class="info-badge">MOBA</span>
                <span class="info-badge">MMO</span>
                <span class="info-badge pink">Браузерные</span>
                <span class="info-badge purple">Инди</span>
            </div>
            <div class="info-modal-section">
                <h4>Бесплатная игра месяца</h4>
                <p>Каждый месяц мы дарим одну платную игру бесплатно всем зарегистрированным пользователям. <strong style="color:var(--accent-pink)">Battle Royale X</strong> — игра этого месяца!</p>
            </div>`
    },
    dlc: {
        title: '🧩 DLC и дополнения',
        html: `
            <div class="info-modal-section">
                <p>Расширяйте свои любимые игры с помощью официальных дополнений, сезонных пропусков и косметических предметов.</p>
            </div>
            <div class="info-modal-section">
                <h4>Типы контента</h4>
                <ul>
                    <li><strong style="color:var(--accent-cyan)">Сюжетные DLC</strong> — новые истории и локации</li>
                    <li><strong style="color:var(--accent-cyan)">Season Pass</strong> — все DLC одним пакетом со скидкой</li>
                    <li><strong style="color:var(--accent-cyan)">Косметика</strong> — скины, питомцы, эффекты</li>
                    <li><strong style="color:var(--accent-cyan)">Саундтреки</strong> — официальная музыка игры</li>
                </ul>
            </div>
            <div class="info-modal-section">
                <h4>Совместимость</h4>
                <p>Все DLC привязаны к аккаунту и доступны на всех ваших устройствах одновременно.</p>
            </div>`
    },
    help: {
        title: '🆘 Помощь',
        html: `
            <div class="info-modal-section">
                <h4>Быстрые ответы</h4>
                <ul>
                    <li>Игра не запускается → проверьте системные требования и обновите драйверы</li>
                    <li>Не приходит письмо → проверьте папку «Спам»</li>
                    <li>Забыли пароль → используйте форму восстановления на странице входа</li>
                    <li>Двойное списание → напишите нам, вернём в течение 24 ч</li>
                </ul>
            </div>
            <hr class="info-divider">
            <div class="info-modal-section">
                <h4>Связаться с поддержкой</h4>
                <div class="info-contact-row">
                    <span class="info-contact-icon">💬</span>
                    <div><div class="info-contact-label">Онлайн-чат</div><div class="info-contact-value">Ежедневно 09:00 – 23:00</div></div>
                </div>
                <div class="info-contact-row">
                    <span class="info-contact-icon">📧</span>
                    <div><div class="info-contact-label">Email</div><div class="info-contact-value">support@nexusgames.ru</div></div>
                </div>
                <div class="info-contact-row">
                    <span class="info-contact-icon">⏱</span>
                    <div><div class="info-contact-label">Среднее время ответа</div><div class="info-contact-value">~2 часа</div></div>
                </div>
            </div>`
    },
    returns: {
        title: '↩️ Возвраты',
        html: `
            <div class="info-modal-section">
                <h4>Условия возврата</h4>
                <ul>
                    <li>Возврат возможен в течение <strong style="color:var(--accent-cyan)">14 дней</strong> после покупки</li>
                    <li>Игровое время не должно превышать <strong style="color:var(--accent-cyan)">2 часов</strong></li>
                    <li>DLC и предметы внутри игры не подлежат возврату</li>
                    <li>Бесплатные игры — без возврата</li>
                </ul>
            </div>
            <div class="info-modal-section">
                <h4>Как оформить возврат</h4>
                <ul>
                    <li>Зайдите в раздел «Мои покупки»</li>
                    <li>Нажмите «Запросить возврат» рядом с игрой</li>
                    <li>Укажите причину и подтвердите</li>
                    <li>Средства вернутся на счёт за <strong style="color:var(--accent-pink)">3–5 рабочих дней</strong></li>
                </ul>
            </div>`
    },
    payment: {
        title: '💳 Способы оплаты',
        html: `
            <div class="info-modal-section">
                <h4>Банковские карты</h4>
                <span class="info-badge">Visa</span>
                <span class="info-badge">Mastercard</span>
                <span class="info-badge">МИР</span>
            </div>
            <div class="info-modal-section">
                <h4>Электронные кошельки</h4>
                <span class="info-badge pink">ЮMoney</span>
                <span class="info-badge pink">QIWI</span>
                <span class="info-badge pink">SberPay</span>
            </div>
            <div class="info-modal-section">
                <h4>Другие способы</h4>
                <span class="info-badge purple">NEXUS Баланс</span>
                <span class="info-badge purple">Подарочные карты</span>
                <span class="info-badge purple">Криптовалюта</span>
            </div>
            <hr class="info-divider">
            <div class="info-modal-section">
                <p>Все транзакции защищены протоколом <strong style="color:var(--accent-cyan)">SSL/TLS</strong>. Данные карт не хранятся на наших серверах.</p>
            </div>`
    },
    faq: {
        title: '❓ FAQ',
        html: `
            <div class="info-modal-section">
                <p><strong style="color:var(--accent-cyan)">Сколько устройств?</strong><br>До 5 устройств одновременно на одном аккаунте.</p>
            </div>
            <div class="info-modal-section">
                <p><strong style="color:var(--accent-cyan)">Можно ли подарить игру?</strong><br>Да! На странице любой игры есть кнопка «Подарить». Введите логин или email получателя.</p>
            </div>
            <div class="info-modal-section">
                <p><strong style="color:var(--accent-cyan)">Игры навсегда?</strong><br>Да, все купленные игры остаются в вашей библиотеке навсегда, без подписки.</p>
            </div>
            <div class="info-modal-section">
                <p><strong style="color:var(--accent-cyan)">Офлайн-режим?</strong><br>Большинство игр поддерживают офлайн-игру после одной активации онлайн.</p>
            </div>
            <div class="info-modal-section">
                <p><strong style="color:var(--accent-cyan)">Нужна подписка?</strong><br>Нет. NEXUS работает без обязательной подписки. Платите только за игры.</p>
            </div>`
    },
    contacts: {
        title: '📬 Контакты',
        html: `
            <div class="info-modal-section">
                <div class="info-contact-row">
                    <span class="info-contact-icon">📧</span>
                    <div><div class="info-contact-label">Email поддержки</div><div class="info-contact-value">support@nexusgames.ru</div></div>
                </div>
                <div class="info-contact-row">
                    <span class="info-contact-icon">📧</span>
                    <div><div class="info-contact-label">Деловые вопросы</div><div class="info-contact-value">business@nexusgames.ru</div></div>
                </div>
                <div class="info-contact-row">
                    <span class="info-contact-icon">📱</span>
                    <div><div class="info-contact-label">Телефон</div><div class="info-contact-value">8-800-NEXUS-00 (бесплатно)</div></div>
                </div>
                <div class="info-contact-row">
                    <span class="info-contact-icon">🏢</span>
                    <div><div class="info-contact-label">Юридический адрес</div><div class="info-contact-value">Москва, ул. Цифровая, д. 2077</div></div>
                </div>
                <div class="info-contact-row">
                    <span class="info-contact-icon">🕐</span>
                    <div><div class="info-contact-label">Часы работы</div><div class="info-contact-value">Пн–Вс, 09:00–23:00 МСК</div></div>
                </div>
            </div>`
    },
    forum: {
        title: '💬 Форум',
        html: `
            <div class="info-modal-section">
                <h4>Горячие темы</h4>
                <div class="forum-post">
                    <div class="forum-post-title">🔥 Лучшие RPG 2026 — делимся впечатлениями</div>
                    <div class="forum-post-meta">342 ответа · Обновлено 2 часа назад</div>
                </div>
                <div class="forum-post">
                    <div class="forum-post-title">⚙️ Настройки графики для слабых ПК</div>
                    <div class="forum-post-meta">87 ответов · Обновлено вчера</div>
                </div>
                <div class="forum-post">
                    <div class="forum-post-title">🎯 Поиск команды для Battle Royale X</div>
                    <div class="forum-post-meta">214 ответа · Онлайн сейчас</div>
                </div>
                <div class="forum-post">
                    <div class="forum-post-title">💡 Идеи для будущих игр NEXUS Studios</div>
                    <div class="forum-post-meta">156 ответов · Обновлено 3 дня назад</div>
                </div>
            </div>
            <div class="info-modal-section">
                <p style="font-size:0.85rem; color:var(--text-secondary)">Форум откроется в полноэкранном режиме после авторизации. <span class="coming-soon-tag">СКОРО</span></p>
            </div>`
    },
    guides: {
        title: '📖 Гайды',
        html: `
            <div class="info-modal-section">
                <h4>Популярные гайды</h4>
                <div class="forum-post">
                    <div class="forum-post-title">🚀 Stellar Odyssey — полное прохождение</div>
                    <div class="forum-post-meta">⭐ 4.9 · Прочитано 12 тыс. раз</div>
                </div>
                <div class="forum-post">
                    <div class="forum-post-title">⚔️ Shadow Legends — билды для PvP</div>
                    <div class="forum-post-meta">⭐ 4.8 · Прочитано 8 тыс. раз</div>
                </div>
                <div class="forum-post">
                    <div class="forum-post-title">🏎️ Velocity Racers — секреты трасс</div>
                    <div class="forum-post-meta">⭐ 4.7 · Прочитано 5 тыс. раз</div>
                </div>
                <div class="forum-post">
                    <div class="forum-post-title">🧟 Zombie Warfare — выживание на харде</div>
                    <div class="forum-post-meta">⭐ 4.9 · Прочитано 9 тыс. раз</div>
                </div>
            </div>
            <div class="info-modal-section">
                <p style="font-size:0.85rem;color:var(--text-secondary)">Создайте собственный гайд и получите <span class="info-badge purple">NEXUS Points</span></p>
            </div>`
    },
    workshop: {
        title: '🔧 Мастерская',
        html: `
            <div class="info-modal-section">
                <p>Мастерская — место, где игроки создают и делятся модификациями, картами, скинами и другим контентом.</p>
            </div>
            <div class="info-modal-section">
                <h4>Что можно публиковать</h4>
                <span class="info-badge">Моды</span>
                <span class="info-badge">Карты</span>
                <span class="info-badge pink">Скины</span>
                <span class="info-badge pink">Звуки</span>
                <span class="info-badge purple">Сценарии</span>
                <span class="info-badge purple">UI темы</span>
            </div>
            <div class="info-modal-section">
                <h4>Топ этой недели</h4>
                <div class="forum-post">
                    <div class="forum-post-title">🗺️ Cyber City — новая карта для Battle Royale X</div>
                    <div class="forum-post-meta">↓ 23 тыс. загрузок · ⭐ 4.9</div>
                </div>
                <div class="forum-post">
                    <div class="forum-post-title">🎨 Neon Overhaul — ресурспак для Shadow Legends</div>
                    <div class="forum-post-meta">↓ 15 тыс. загрузок · ⭐ 4.8</div>
                </div>
            </div>
            <div class="info-modal-section">
                <p style="font-size:0.85rem;color:var(--text-secondary)">Полный доступ к мастерской — после авторизации. <span class="coming-soon-tag">СКОРО</span></p>
            </div>`
    },
    streams: {
        title: '📺 Трансляции',
        html: `
            <div class="info-modal-section">
                <h4>Сейчас в эфире</h4>
                <div class="stream-card">
                    <span class="stream-live">LIVE</span>
                    <div>
                        <div class="forum-post-title">ProGamer2077 играет в Shadow Legends</div>
                        <div class="forum-post-meta">👁 4 821 зрителей</div>
                    </div>
                </div>
                <div class="stream-card">
                    <span class="stream-live">LIVE</span>
                    <div>
                        <div class="forum-post-title">NexusTV — официальный турнир Battle Royale X</div>
                        <div class="forum-post-meta">👁 18 340 зрителей</div>
                    </div>
                </div>
                <div class="stream-card">
                    <span class="stream-live">LIVE</span>
                    <div>
                        <div class="forum-post-title">SpeedRun_RU — Stellar Odyssey любой%</div>
                        <div class="forum-post-meta">👁 1 203 зрителей</div>
                    </div>
                </div>
            </div>
            <div class="info-modal-section">
                <p style="font-size:0.85rem;color:var(--text-secondary)">Начните свою трансляцию прямо на NEXUS — без сторонних сервисов. <span class="coming-soon-tag">СКОРО</span></p>
            </div>`
    },
    rewards: {
        title: '🏆 Награды',
        html: `
            <div class="info-modal-section">
                <p>Зарабатывайте <strong style="color:var(--accent-purple)">NEXUS Points</strong> за покупки, отзывы и активность. Обменивайте на скидки и эксклюзивные предметы.</p>
            </div>
            <div class="info-modal-section">
                <h4>Как заработать очки</h4>
                <div class="reward-row">
                    <div class="reward-info"><span class="reward-icon">🛒</span><span class="reward-name">Покупка игры</span></div>
                    <span class="reward-pts">+100 pts / 100 ₽</span>
                </div>
                <div class="reward-row">
                    <div class="reward-info"><span class="reward-icon">✍️</span><span class="reward-name">Написать отзыв</span></div>
                    <span class="reward-pts">+50 pts</span>
                </div>
                <div class="reward-row">
                    <div class="reward-info"><span class="reward-icon">👥</span><span class="reward-name">Пригласить друга</span></div>
                    <span class="reward-pts">+500 pts</span>
                </div>
                <div class="reward-row">
                    <div class="reward-info"><span class="reward-icon">🎮</span><span class="reward-name">Ежедневный вход</span></div>
                    <span class="reward-pts">+10 pts</span>
                </div>
            </div>
            <div class="info-modal-section">
                <h4>Уровни</h4>
                <span class="info-badge">Новичок 0–999</span>
                <span class="info-badge pink">Игрок 1k–4999</span>
                <span class="info-badge purple">Мастер 5k+</span>
            </div>`
    }
};

// ── Info Modal Functions ──────────────────────────────────────
function openInfoModal(type) {
    const data = infoContent[type];
    if (!data) return;
    document.getElementById('infoModalContent').innerHTML = `
        <h2 class="info-modal-title">${data.title}</h2>
        ${data.html}
    `;
    document.getElementById('infoModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeInfoModalDirect() {
    document.getElementById('infoModal').classList.remove('active');
    document.body.style.overflow = 'auto';
}

function closeInfoModal(e) {
    if (e.target === e.currentTarget) closeInfoModalDirect();
}

// ── Footer Shop Links ─────────────────────────────────────────
function footerFilterGames(e, filter) {
    e.preventDefault();
    if (filter === 'free') {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        renderGames('free');
    } else {
        const filterBtn = document.querySelector(`.filter-btn[data-filter="${filter}"]`);
        if (filterBtn) filterBtn.click();
    }
    window.scrollTo({ top: document.querySelector('.games-section').offsetTop - 100, behavior: 'smooth' });
}

// ── Event Wiring ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {
    // ESC closes info modal
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && document.getElementById('infoModal').classList.contains('active')) {
            closeInfoModalDirect();
        }
    });
});
