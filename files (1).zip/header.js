/* ═══════════════════════════════════════
   NEXUS GAMES — Header JavaScript
   (Auth, Login Modal, Purchase Nav)
   ═══════════════════════════════════════ */

// ── Auth Config ──────────────────────────────────────────────
const USERS = [
    { username: 'admin', password: 'admin123', role: 'admin' },
    { username: 'user',  password: 'user123',  role: 'user'  }
];

// ── Login Modal ───────────────────────────────────────────────
function openLoginModal() {
    document.getElementById('loginModal').classList.add('active');
    document.getElementById('loginUsername').focus();
    document.body.style.overflow = 'hidden';
}

function closeLoginModal() {
    document.getElementById('loginModal').classList.remove('active');
    document.body.style.overflow = 'auto';
    document.getElementById('loginError').classList.remove('visible');
    document.getElementById('loginUsername').value = '';
    document.getElementById('loginPassword').value = '';
}

function handleLogin() {
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errorEl  = document.getElementById('loginError');

    const match = USERS.find(u => u.username === username && u.password === password);

    if (!match) {
        errorEl.classList.add('visible');
        document.getElementById('loginPassword').value = '';
        return;
    }

    errorEl.classList.remove('visible');
    closeLoginModal();

    if (match.role === 'admin') {
        window.location.href = 'admin-panel.html';
    } else {
        setLoggedInState(match.username);
    }
}

function setLoggedInState(username) {
    const loginBtnHeader = document.getElementById('loginBtnHeader');
    const loginNavLink   = document.getElementById('loginNavLink');
    const initials       = username.substring(0, 2).toUpperCase();

    loginBtnHeader.outerHTML = `
        <div class="user-badge">
            <div class="avatar">${initials}</div>
            <span>${username}</span>
            <button class="logout-btn" onclick="handleLogout()">✕</button>
        </div>`;

    loginNavLink.textContent = '👤 ' + username;
    loginNavLink.style.pointerEvents = 'none';
}

function handleLogout() {
    location.reload();
}

// ── Purchase Modal ────────────────────────────────────────────
let selectedCard        = null;
let purchaseCurrentStep = 1;

function openPurchaseModal(e, gameName, price) {
    if (e) e.preventDefault();
    selectedCard        = null;
    purchaseCurrentStep = 1;

    document.getElementById('purchaseGameName').textContent  = gameName || '—';
    document.getElementById('purchaseTotalAmt').textContent  = price    || '—';
    document.getElementById('successGameName').textContent   = gameName || '—';

    document.querySelectorAll('.card-option').forEach(o => o.classList.remove('selected'));
    document.querySelectorAll('.p-error').forEach(e => e.classList.remove('visible'));
    ['cardName', 'cardNumber', 'cardExpiry', 'cardCvv'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });

    setPurchaseStep(1);
    document.getElementById('purchaseModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closePurchaseModal() {
    document.getElementById('purchaseModal').classList.remove('active');
    document.body.style.overflow = 'auto';
}

function selectCard(type) {
    selectedCard = type;
    document.getElementById('visa-opt').classList.toggle('selected', type === 'visa');
    document.getElementById('mc-opt').classList.toggle('selected', type === 'mastercard');
    document.getElementById('pErr1').classList.remove('visible');
}

function setPurchaseStep(step) {
    purchaseCurrentStep = step;
    for (let i = 1; i <= 3; i++) {
        document.getElementById('pstep' + i).classList.toggle('active', i === step);
        const dot = document.getElementById('sd' + i);
        dot.classList.remove('active', 'done');
        if (i < step)      dot.classList.add('done');
        else if (i === step) dot.classList.add('active');
        document.getElementById('sl-' + i).classList.toggle('active', i === step);
    }
    for (let i = 1; i <= 2; i++) {
        document.getElementById('sl' + i).classList.toggle('done', i < step);
    }
}

function goToStep2() {
    if (!selectedCard) {
        document.getElementById('pErr1').classList.add('visible');
        return;
    }
    setPurchaseStep(2);
}

function goToStep3() {
    const name = document.getElementById('cardName').value.trim();
    const num  = document.getElementById('cardNumber').value.trim();
    const exp  = document.getElementById('cardExpiry').value.trim();
    const cvv  = document.getElementById('cardCvv').value.trim();
    if (!name || !num || !exp || !cvv) {
        document.getElementById('pErr2').classList.add('visible');
        return;
    }
    document.getElementById('pErr2').classList.remove('visible');
    setPurchaseStep(3);
}

// ── Event Wiring (runs after DOM ready) ──────────────────────
document.addEventListener('DOMContentLoaded', function () {

    // Card number auto-formatting
    document.getElementById('cardNumber').addEventListener('input', function (e) {
        let val = e.target.value.replace(/\D/g, '').substring(0, 16);
        e.target.value = val.replace(/(.{4})/g, '$1 ').trim();
    });
    document.getElementById('cardExpiry').addEventListener('input', function (e) {
        let val = e.target.value.replace(/\D/g, '').substring(0, 4);
        if (val.length >= 3) val = val.substring(0, 2) + '/' + val.substring(2);
        e.target.value = val;
    });
    document.getElementById('cardName').addEventListener('input', function (e) {
        e.target.value = e.target.value.toUpperCase();
    });

    // Close purchase modal on overlay click
    document.getElementById('purchaseModal').addEventListener('click', function (e) {
        if (e.target === this) closePurchaseModal();
    });

    // Close login modal on overlay click
    document.getElementById('loginModal').addEventListener('click', function (e) {
        if (e.target === this) closeLoginModal();
    });

    // Wire nav login link
    document.getElementById('loginNavLink').addEventListener('click', function (e) {
        e.preventDefault();
        openLoginModal();
    });

    // Wire purchase nav link
    document.getElementById('purchaseNavLink').addEventListener('click', function (e) {
        e.preventDefault();
        openPurchaseModal(null, 'Выбранная игра', '999 ₽');
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            if (document.getElementById('purchaseModal').classList.contains('active')) closePurchaseModal();
            if (document.getElementById('loginModal').classList.contains('active'))    closeLoginModal();
        }
        if (e.key === 'Enter' && document.getElementById('loginModal').classList.contains('active')) {
            handleLogin();
        }
    });
});
